﻿# =====================================================================
#  Modules\Restore.ps1
#  Полный откат всех твиков программы к значениям Windows по умолчанию.
#  Каждый шаг безопасен: если значение никогда не менялось, действие
#  просто ничего не делает (ErrorAction SilentlyContinue).
# =====================================================================

function Invoke-RestoreAll {
    Write-Header -Title "Восстановление всех настроек по умолчанию"
    Write-Host " Будут отменены все твики, применённые через PC1 Optimizer:" -ForegroundColor $Script:Theme.Text
    Write-Host "  - HPET, компрессия памяти, Defender, Copilot, обновления" -ForegroundColor $Script:Theme.Muted
    Write-Host "  - Поиск на панели задач, переключение раскладки" -ForegroundColor $Script:Theme.Muted
    Write-Host "  - NVIDIA, план электропитания, HAGS, Game Bar, FSO" -ForegroundColor $Script:Theme.Muted
    Write-Host "  - Сетевые/USB твики энергосбережения, Nagle Algorithm" -ForegroundColor $Script:Theme.Muted
    Write-Host ""
    Write-Host " Приложения (Edge, Copilot и т.д.), удалённые вручную через" -ForegroundColor $Script:Theme.Warning
    Write-Host " 'Очистку системы', этот пункт не переустанавливает." -ForegroundColor $Script:Theme.Warning

    if (-not (Show-Confirm -Message "Восстановить все настройки по умолчанию?")) { return }

    $results = @()

    # ---------- Система: HPET, память, Defender, Copilot, обновления ----------
    $results += Invoke-SafeAction -Description "HPET: возврат к значению по умолчанию" -Action {
        bcdedit /deletevalue useplatformclock 2>$null | Out-Null
        bcdedit /deletevalue disabledynamictick 2>$null | Out-Null
    }
    $results += Invoke-SafeAction -Description "Компрессия памяти: включение (по умолчанию)" -Action {
        Enable-MMAgent -MemoryCompression -ErrorAction SilentlyContinue | Out-Null
    }
    $results += Invoke-SafeAction -Description "Windows Defender: включение" -Action {
        Set-MpPreference -DisableRealtimeMonitoring $false -ErrorAction SilentlyContinue
        Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender" -Name "DisableAntiSpyware" -ErrorAction SilentlyContinue
    }
    $results += Invoke-SafeAction -Description "Copilot: снятие блокировки" -Action {
        Remove-Item -Path "HKCU:\Software\Policies\Microsoft\Windows\WindowsCopilot" -Force -ErrorAction SilentlyContinue
        Remove-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot" -Force -ErrorAction SilentlyContinue
    }
    $results += Invoke-SafeAction -Description "Обновления Windows: снятие паузы" -Action {
        $path = "HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings"
        foreach ($n in @("PauseUpdatesExpiryTime","PauseFeatureUpdatesEndTime","PauseFeatureUpdatesStartTime","PauseQualityUpdatesEndTime","PauseQualityUpdatesStartTime","PauseUpdatesStartTime")) {
            Remove-ItemProperty -Path $path -Name $n -ErrorAction SilentlyContinue
        }
    }
    $results += Invoke-SafeAction -Description "Поиск на панели задач: включение" -Action {
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Search" -Name "SearchboxTaskbarMode" -Value 1 -Type DWord -Force
    }
    $results += Invoke-SafeAction -Description "Переключение раскладки клавиатуры: восстановление" -Action {
        $hivePath = "$env:LOCALAPPDATA\Packages\MicrosoftWindows.Client.CBS_cw5n1h2txyewy\Settings\settings.dat"
        if (Test-Path $hivePath) {
            reg load "HKLM\Settings_PC1Tmp" $hivePath 2>$null | Out-Null
            reg delete "HKLM\Settings_PC1Tmp\LocalState\DisabledApps" /v "Microsoft.Windows.TextInputHost" /f 2>$null | Out-Null
            reg unload "HKLM\Settings_PC1Tmp" 2>$null | Out-Null
        }
    }

    # ---------- NVIDIA ----------
    $results += Invoke-SafeAction -Description "NVIDIA: сброс твиков" -Action {
        reg delete "HKLM\System\ControlSet001\Services\nvlddmkm\Parameters\Global\NVTweak" /v "NvCplPhysxAuto" /f 2>$null | Out-Null
        reg add "HKLM\System\ControlSet001\Services\nvlddmkm\Parameters\Global\NVTweak" /v "NvDevToolsVisible" /t REG_DWORD /d "0" /f 2>$null | Out-Null
        reg add "HKCU\Software\NVIDIA Corporation\NvTray" /v "StartOnLogin" /t REG_DWORD /d "1" /f 2>$null | Out-Null
        Get-Service -Name "NvTelemetryContainer" -ErrorAction SilentlyContinue | Set-Service -StartupType Automatic -ErrorAction SilentlyContinue
    }

    # ---------- Игровые настройки ----------
    $results += Invoke-SafeAction -Description "План электропитания: Сбалансированный" -Action {
        powercfg /setactive "381b4222-f694-41f0-9685-ff5bb260df2e" 2>$null | Out-Null
    }
    $results += Invoke-SafeAction -Description "HAGS: значение по умолчанию" -Action {
        Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" -Name "HwSchMode" -Value 1 -Type DWord -Force -ErrorAction SilentlyContinue
    }
    $results += Invoke-SafeAction -Description "Game Bar / Game Mode: включение" -Action {
        Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR" -Name "AppCaptureEnabled" -Value 1 -Type DWord -Force -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\GameBar" -Name "AutoGameModeEnabled" -Value 1 -Type DWord -Force -ErrorAction SilentlyContinue
    }
    $results += Invoke-SafeAction -Description "Полноэкранные оптимизации: значение по умолчанию" -Action {
        Remove-ItemProperty -Path "HKCU:\System\GameConfigStore" -Name "GameDVR_FSEBehaviorMode" -ErrorAction SilentlyContinue
        Remove-ItemProperty -Path "HKCU:\System\GameConfigStore" -Name "GameDVR_HonorUserFSEBehaviorMode" -ErrorAction SilentlyContinue
    }
    $results += Invoke-SafeAction -Description "Приоритет игр в планировщике: значение по умолчанию" -Action {
        $path = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile"
        Set-ItemProperty -Path $path -Name "SystemResponsiveness" -Value 20 -Type DWord -Force -ErrorAction SilentlyContinue
        Remove-Item -Path "$path\Tasks\Games" -Force -Recurse -ErrorAction SilentlyContinue
    }

    # ---------- Сеть ----------
    $results += Invoke-SafeAction -Description "Энергосбережение сетевого адаптера: возврат к умолчанию драйвера" -Action {
        $keys = Get-ChildItem "HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}" -ErrorAction SilentlyContinue
        foreach ($key in $keys) {
            foreach ($prop in @("AdvancedEEE","*EEE","EEELinkAdvertisement","SipsEnabled","ULPMode","GigaLite","EnableGreenEthernet","PowerSavingMode")) {
                Remove-ItemProperty -Path $key.PSPath -Name $prop -ErrorAction SilentlyContinue
            }
            Remove-ItemProperty -Path $key.PSPath -Name "EnhancedPowerManagementEnabled" -ErrorAction SilentlyContinue
        }
    }
    $results += Invoke-SafeAction -Description "Энергосбережение USB: возврат к умолчанию драйвера" -Action {
        $usbKeys = Get-ChildItem -Path "HKLM:\SYSTEM\CurrentControlSet\Enum\USB" -Recurse -ErrorAction SilentlyContinue |
            Where-Object { $_.PSChildName -eq "Device Parameters" }
        foreach ($key in $usbKeys) {
            Remove-ItemProperty -Path $key.PSPath -Name "EnhancedPowerManagementEnabled" -ErrorAction SilentlyContinue
            Remove-ItemProperty -Path $key.PSPath -Name "SelectiveSuspendEnabled" -ErrorAction SilentlyContinue
            Remove-ItemProperty -Path $key.PSPath -Name "SelectiveSuspendOn" -ErrorAction SilentlyContinue
        }
    }
    $results += Invoke-SafeAction -Description "Nagle Algorithm: возврат к умолчанию" -Action {
        $base = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces"
        Get-ChildItem $base -ErrorAction SilentlyContinue | ForEach-Object {
            Remove-ItemProperty -Path $_.PSPath -Name "TcpAckFrequency" -ErrorAction SilentlyContinue
            Remove-ItemProperty -Path $_.PSPath -Name "TCPNoDelay" -ErrorAction SilentlyContinue
        }
    }

    Show-ResultList -Results $results -Title "Восстановление настроек"
    Write-Host " Часть изменений (HPET, HAGS, план питания) применится после перезагрузки." -ForegroundColor $Script:Theme.Warning
    Start-Sleep -Seconds 2
}
