﻿# =====================================================================
#  Modules\System.ps1
#  Оптимизация Windows: HPET, память, Defender, Copilot, Edge, апдейты.
#
#  ИСПРАВЛЕНО (анализ оригинальных скриптов):
#   1. Строка поиска на панели задач пропадала из-за принудительной
#      установки SearchboxTaskbarMode=0 и остановки процесса SearchHost
#      в "6. Панель управления.ps1". Теперь это отдельный необязательный
#      пункт, по умолчанию поиск не трогаем.
#   2. Переключение языка (Shift+Alt) переставало работать, потому что
#      тот же скрипт принудительно останавливал и блокировал процесс
#      TextInputHost через реестр DisabledApps. TextInputHost отвечает
#      за индикатор/переключение раскладки в современной Windows —
#      его больше не трогаем.
# =====================================================================

function Invoke-SystemMenu {
    while ($true) {
        $items = @(
            "Высокоточный таймер событий (HPET)",
            "Компрессия памяти",
            "Windows Defender",
            "Windows Copilot",
            "Приостановить обновления Windows на 365 дней",
            "Удалить Microsoft Edge",
            "Поиск на панели задач (диагностика/восстановление)",
            "Переключение раскладки клавиатуры (диагностика/восстановление)"
        )
        $sel = Show-Menu -Title "Оптимизация Windows" -Items $items
        switch ($sel) {
            -1 { return }
            0 { Invoke-HpetMenu }
            1 { Invoke-MemoryCompressionMenu }
            2 { Invoke-DefenderMenu }
            3 { Invoke-CopilotMenu }
            4 { Invoke-PauseUpdates }
            5 { Invoke-RemoveEdge }
            6 { Invoke-SearchFix }
            7 { Invoke-LanguageSwitchFix }
        }
    }
}

# ---------------------------------------------------------------------
#  HPET
# ---------------------------------------------------------------------
function Invoke-HpetMenu {
    $items = @("Отключить HPET (рекомендуется для игр)", "Вернуть по умолчанию")
    $sel = Show-Menu -Title "Высокоточный таймер событий" -Items $items
    if ($sel -lt 0) { return }

    $results = @()
    if ($sel -eq 0) {
        $results += Invoke-SafeAction -Description "Отключение HPET (bcdedit)" -Action {
            bcdedit /set useplatformclock false | Out-Null
            bcdedit /set disabledynamictick yes | Out-Null
        }
    } else {
        $results += Invoke-SafeAction -Description "Возврат HPET к значениям по умолчанию" -Action {
            bcdedit /deletevalue useplatformclock | Out-Null
            bcdedit /set disabledynamictick yes | Out-Null
        }
    }
    Show-ResultList -Results $results
    Write-Host " Изменения вступят в силу после перезагрузки." -ForegroundColor $Script:Theme.Warning
    Start-Sleep -Seconds 2
}

# ---------------------------------------------------------------------
#  Компрессия памяти
# ---------------------------------------------------------------------
function Invoke-MemoryCompressionMenu {
    $items = @("Выключить компрессию памяти (рекомендуется)", "Включить компрессию памяти", "Проверить текущее состояние")
    $sel = Show-Menu -Title "Компрессия памяти" -Items $items
    if ($sel -lt 0) { return }

    switch ($sel) {
        0 {
            $r = Invoke-SafeAction -Description "Отключение компрессии памяти" -Action { Disable-MMAgent -MemoryCompression -ErrorAction Stop }
            Show-ResultList -Results @($r)
        }
        1 {
            $r = Invoke-SafeAction -Description "Включение компрессии памяти" -Action { Enable-MMAgent -MemoryCompression -ErrorAction Stop }
            Show-ResultList -Results @($r)
        }
        2 {
            Write-Header -Title "Состояние MMAgent"
            Get-MMAgent | Format-List | Out-Host
            Write-Host " Нажмите любую клавишу для возврата..." -ForegroundColor $Script:Theme.Muted
            [void][System.Console]::ReadKey($true)
        }
    }
}

# ---------------------------------------------------------------------
#  Windows Defender — потенциально опасное действие, требует явного
#  подтверждения и предупреждения.
# ---------------------------------------------------------------------
function Invoke-DefenderMenu {
    $items = @("Отключить Defender", "Включить Defender обратно")
    $sel = Show-Menu -Title "Windows Defender" -Items $items
    if ($sel -lt 0) { return }

    if ($sel -eq 0) {
        Write-Host ""
        Write-Host " Предупреждение: отключение антивируса снижает защиту компьютера." -ForegroundColor $Script:Theme.Warning
        Write-Host " Делайте это только если понимаете риски и используете другую защиту." -ForegroundColor $Script:Theme.Warning
        if (-not (Show-Confirm -Message "Точно отключить Windows Defender?")) { return }

        $results = @()
        $results += Invoke-SafeAction -Description "Отключение Real-Time Protection" -Action {
            Set-MpPreference -DisableRealtimeMonitoring $true -ErrorAction Stop
        }
        $results += Invoke-SafeAction -Description "Отключение Defender через групповую политику (реестр)" -Action {
            New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender" -Force | Out-Null
            Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender" -Name "DisableAntiSpyware" -Value 1 -Type DWord -Force
        }
        Show-ResultList -Results $results
    } else {
        $results = @()
        $results += Invoke-SafeAction -Description "Включение Real-Time Protection" -Action {
            Set-MpPreference -DisableRealtimeMonitoring $false -ErrorAction Stop
        }
        $results += Invoke-SafeAction -Description "Снятие политики отключения Defender" -Action {
            Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender" -Name "DisableAntiSpyware" -ErrorAction SilentlyContinue
        }
        Show-ResultList -Results $results
    }
}

# ---------------------------------------------------------------------
#  Copilot
# ---------------------------------------------------------------------
function Invoke-CopilotMenu {
    $items = @("Отключить Copilot", "Вернуть Copilot")
    $sel = Show-Menu -Title "Windows Copilot" -Items $items
    if ($sel -lt 0) { return }

    if ($sel -eq 0) {
        $results = @()
        $results += Invoke-SafeAction -Description "Удаление пакета Copilot" -Action {
            Get-AppXPackage -AllUsers | Where-Object { $_.Name -like "*Copilot*" } |
                Remove-AppxPackage -ErrorAction SilentlyContinue
        }
        $results += Invoke-SafeAction -Description "Отключение Copilot через реестр (HKCU)" -Action {
            New-Item -Path "HKCU:\Software\Policies\Microsoft\Windows\WindowsCopilot" -Force | Out-Null
            Set-ItemProperty -Path "HKCU:\Software\Policies\Microsoft\Windows\WindowsCopilot" -Name "TurnOffWindowsCopilot" -Value 1 -Type DWord
        }
        $results += Invoke-SafeAction -Description "Отключение Copilot через реестр (HKLM)" -Action {
            New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot" -Force | Out-Null
            Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot" -Name "TurnOffWindowsCopilot" -Value 1 -Type DWord
        }
        Show-ResultList -Results $results
    } else {
        $results = @()
        $results += Invoke-SafeAction -Description "Переустановка пакета Copilot" -Action {
            Get-AppXPackage -AllUsers | Where-Object { $_.Name -like "*Copilot*" } | ForEach-Object {
                Add-AppxPackage -DisableDevelopmentMode -Register -ErrorAction SilentlyContinue "$($_.InstallLocation)\AppXManifest.xml"
            }
        }
        $results += Invoke-SafeAction -Description "Снятие политики отключения Copilot" -Action {
            Remove-Item -Path "HKCU:\Software\Policies\Microsoft\Windows\WindowsCopilot" -Force -ErrorAction SilentlyContinue
            Remove-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot" -Force -ErrorAction SilentlyContinue
        }
        Show-ResultList -Results $results
    }
}

# ---------------------------------------------------------------------
#  Приостановка обновлений на 365 дней
# ---------------------------------------------------------------------
function Invoke-PauseUpdates {
    Write-Header -Title "Приостановка обновлений Windows"
    if (-not (Show-Confirm -Message "Приостановить обновления Windows на 365 дней?")) { return }

    $r = Invoke-SafeAction -Description "Приостановка обновлений Windows на 365 дней" -Action {
        $pause = (Get-Date).AddDays(365).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
        $today = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
        $path = "HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings"
        if (-not (Test-Path $path)) { New-Item -Path $path -Force | Out-Null }
        Set-ItemProperty -Path $path -Name "PauseUpdatesExpiryTime"        -Value $pause -Force
        Set-ItemProperty -Path $path -Name "PauseFeatureUpdatesEndTime"    -Value $pause -Force
        Set-ItemProperty -Path $path -Name "PauseFeatureUpdatesStartTime" -Value $today -Force
        Set-ItemProperty -Path $path -Name "PauseQualityUpdatesEndTime"   -Value $pause -Force
        Set-ItemProperty -Path $path -Name "PauseQualityUpdatesStartTime" -Value $today -Force
        Set-ItemProperty -Path $path -Name "PauseUpdatesStartTime"        -Value $today -Force
    }
    Show-ResultList -Results @($r)
}

# ---------------------------------------------------------------------
#  Удаление Edge — защищено подтверждением (пункт из "никогда не удалять
#  автоматически", удаляем только по явному выбору пользователя)
# ---------------------------------------------------------------------
function Invoke-RemoveEdge {
    Write-Header -Title "Удаление Microsoft Edge"
    Write-Host " Предупреждение: некоторые компоненты Windows используют" -ForegroundColor $Script:Theme.Warning
    Write-Host " WebView2 на основе Edge. Возможны побочные эффекты." -ForegroundColor $Script:Theme.Warning
    if (-not (Show-Confirm -Message "Точно удалить Microsoft Edge?")) { return }

    $results = @()
    $results += Invoke-SafeAction -Description "Остановка процессов Edge" -Action {
        Get-Process | Where-Object { $_.ProcessName -like "*msedge*" } | Stop-Process -Force -ErrorAction SilentlyContinue
    }
    $results += Invoke-SafeAction -Description "Удаление пакетов Edge (AppX)" -Action {
        Get-AppXPackage -AllUsers | Where-Object { $_.Name -like "*MicrosoftEdge*" } | Remove-AppxPackage -ErrorAction SilentlyContinue
    }
    Show-ResultList -Results $results
}

# ---------------------------------------------------------------------
#  Диагностика/восстановление поиска на панели задач
# ---------------------------------------------------------------------
function Invoke-SearchFix {
    $items = @("Включить поиск на панели задач (значение по умолчанию)", "Скрыть поиск на панели задач")
    $sel = Show-Menu -Title "Поиск на панели задач" -Items $items
    if ($sel -lt 0) { return }

    $value = if ($sel -eq 0) { 1 } else { 0 }
    $r = Invoke-SafeAction -Description "Изменение режима поиска на панели задач" -Action {
        Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Search" -Name "SearchboxTaskbarMode" -Value $value -Type DWord -Force
        Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
    }
    Show-ResultList -Results @($r)
}

# ---------------------------------------------------------------------
#  Диагностика/восстановление переключения раскладки
# ---------------------------------------------------------------------
function Invoke-LanguageSwitchFix {
    Write-Header -Title "Переключение раскладки клавиатуры"
    Write-Host " Эта функция снимает возможную блокировку процесса TextInputHost," -ForegroundColor $Script:Theme.Text
    Write-Host " из-за которой перестаёт работать Shift+Alt." -ForegroundColor $Script:Theme.Text
    if (-not (Show-Confirm -Message "Восстановить переключение раскладки?")) { return }

    $r = Invoke-SafeAction -Description "Снятие блокировки TextInputHost" -Action {
        $regPath = "HKLM:\Settings\LocalState\DisabledApps"
        $hivePath = "$env:LOCALAPPDATA\Packages\MicrosoftWindows.Client.CBS_cw5n1h2txyewy\Settings\settings.dat"
        if (Test-Path $hivePath) {
            reg load "HKLM\Settings_PC1Tmp" $hivePath 2>$null | Out-Null
            reg delete "HKLM\Settings_PC1Tmp\LocalState\DisabledApps" /v "Microsoft.Windows.TextInputHost" /f 2>$null | Out-Null
            reg unload "HKLM\Settings_PC1Tmp" 2>$null | Out-Null
        }
        Start-Process "TextInputHost.exe" -ErrorAction SilentlyContinue
    }
    Show-ResultList -Results @($r)
}
