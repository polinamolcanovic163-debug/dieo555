﻿# =====================================================================
#  Modules\Nvidia.ps1
#  Настройки NVIDIA: производительность, MSI mode, телеметрия.
# =====================================================================

function Invoke-NvidiaMenu {
    while ($true) {
        $items = @(
            "Максимальная производительность",
            "MSI Mode для видеокарты",
            "Отключить телеметрию NVIDIA",
            "Сбросить настройки NVIDIA"
        )
        $sel = Show-Menu -Title "NVIDIA" -Items $items
        switch ($sel) {
            -1 { return }
            0 { Invoke-NvidiaPerformance }
            1 { Invoke-NvidiaMsiMode }
            2 { Invoke-NvidiaTelemetryOff }
            3 { Invoke-NvidiaReset }
        }
    }
}

function Invoke-NvidiaPerformance {
    Write-Header -Title "NVIDIA — максимальная производительность"
    if (-not (Show-Confirm -Message "Применить набор твиков производительности NVIDIA?")) { return }

    $results = @()
    $results += Invoke-SafeAction -Description "PhysX на GPU" -Action {
        reg add "HKLM\System\ControlSet001\Services\nvlddmkm\Parameters\Global\NVTweak" /v "NvCplPhysxAuto" /t REG_DWORD /d "0" /f | Out-Null
    }
    $results += Invoke-SafeAction -Description "Включение Developer Settings" -Action {
        reg add "HKLM\System\ControlSet001\Services\nvlddmkm\Parameters\Global\NVTweak" /v "NvDevToolsVisible" /t REG_DWORD /d "1" /f | Out-Null
    }
    $results += Invoke-SafeAction -Description "Доступ к счётчикам производительности GPU для всех пользователей" -Action {
        $subkeys = Get-ChildItem -Path "Registry::HKLM\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}" -Force -ErrorAction SilentlyContinue
        foreach ($key in $subkeys) {
            if ($key -notlike "*Configuration") {
                reg add "$key" /v "RmProfilingAdminOnly" /t REG_DWORD /d "0" /f | Out-Null
            }
        }
        reg add "HKLM\System\ControlSet001\Services\nvlddmkm\Parameters\Global\NVTweak" /v "RmProfilingAdminOnly" /t REG_DWORD /d "0" /f | Out-Null
    }
    $results += Invoke-SafeAction -Description "Отключение значка NVIDIA в трее при входе" -Action {
        reg add "HKCU\Software\NVIDIA Corporation\NvTray" /v "StartOnLogin" /t REG_DWORD /d "0" /f | Out-Null
    }
    $results += Invoke-SafeAction -Description "Включение Legacy Sharpen" -Action {
        reg add "HKLM\SYSTEM\CurrentControlSet\Services\nvlddmkm\FTS" /v "EnableGR535" /t REG_DWORD /d "0" /f | Out-Null
        reg add "HKLM\SYSTEM\ControlSet001\Services\nvlddmkm\Parameters\FTS" /v "EnableGR535" /t REG_DWORD /d "0" /f | Out-Null
        reg add "HKLM\SYSTEM\CurrentControlSet\Services\nvlddmkm\Parameters\FTS" /v "EnableGR535" /t REG_DWORD /d "0" /f | Out-Null
    }
    Show-ResultList -Results $results
}

function Invoke-NvidiaMsiMode {
    Write-Header -Title "NVIDIA — MSI Mode"
    Write-Host " MSI Mode может снизить задержки прерываний GPU на некоторых системах." -ForegroundColor $Script:Theme.Text
    if (-not (Show-Confirm -Message "Включить MSI Mode для видеокарты?")) { return }

    $r = Invoke-SafeAction -Description "Включение MSI Mode для GPU" -Action {
        $gpu = Get-PnpDevice -Class Display -Status OK -ErrorAction Stop | Select-Object -First 1
        if (-not $gpu) { throw "Видеокарта не найдена" }
        $devPath = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($gpu.InstanceId)\Device Parameters\Interrupt Management\MessageSignaledInterruptProperties"
        if (-not (Test-Path $devPath)) { New-Item -Path $devPath -Force | Out-Null }
        Set-ItemProperty -Path $devPath -Name "MSISupported" -Value 1 -Type DWord -Force
    }
    Show-ResultList -Results @($r)
}

function Invoke-NvidiaTelemetryOff {
    Write-Header -Title "NVIDIA — отключение телеметрии"
    if (-not (Show-Confirm -Message "Отключить телеметрию NVIDIA?")) { return }

    $results = @()
    $results += Invoke-SafeAction -Description "Остановка службы NVIDIA Telemetry" -Action {
        Get-Service -Name "NvTelemetryContainer" -ErrorAction SilentlyContinue | Stop-Service -Force -ErrorAction SilentlyContinue
        Set-Service -Name "NvTelemetryContainer" -StartupType Disabled -ErrorAction SilentlyContinue
    }
    $results += Invoke-SafeAction -Description "Отключение задач телеметрии в планировщике" -Action {
        Get-ScheduledTask -TaskName "NvTm*" -ErrorAction SilentlyContinue | Disable-ScheduledTask -ErrorAction SilentlyContinue
    }
    Show-ResultList -Results $results
}

function Invoke-NvidiaReset {
    Write-Header -Title "NVIDIA — сброс настроек"
    if (-not (Show-Confirm -Message "Сбросить твики NVIDIA к значениям по умолчанию?")) { return }

    $results = @()
    $results += Invoke-SafeAction -Description "Возврат PhysX к автоматическому режиму" -Action {
        reg delete "HKLM\System\ControlSet001\Services\nvlddmkm\Parameters\Global\NVTweak" /v "NvCplPhysxAuto" /f 2>$null | Out-Null
    }
    $results += Invoke-SafeAction -Description "Отключение Developer Settings" -Action {
        reg add "HKLM\System\ControlSet001\Services\nvlddmkm\Parameters\Global\NVTweak" /v "NvDevToolsVisible" /t REG_DWORD /d "0" /f | Out-Null
    }
    $results += Invoke-SafeAction -Description "Включение значка NVIDIA в трее при входе" -Action {
        reg add "HKCU\Software\NVIDIA Corporation\NvTray" /v "StartOnLogin" /t REG_DWORD /d "1" /f | Out-Null
    }
    Show-ResultList -Results $results
}
