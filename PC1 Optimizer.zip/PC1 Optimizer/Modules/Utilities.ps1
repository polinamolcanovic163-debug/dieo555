﻿# =====================================================================
#  Modules\Utilities.ps1
#  Общий движок: права администратора, логирование, меню, диалоги.
# =====================================================================

# ---------------------------------------------------------------------
#  Права администратора
# ---------------------------------------------------------------------
function Test-IsAdmin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Assert-Admin {
    param([Parameter(Mandatory)][string]$ScriptPath)
    if (-not (Test-IsAdmin)) {
        $psPath = (Get-Process -Id $PID).Path
        Start-Process $psPath -ArgumentList @(
            "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$ScriptPath`""
        ) -Verb RunAs
        exit
    }
}

# ---------------------------------------------------------------------
#  Логирование
# ---------------------------------------------------------------------
$Script:LogFile = $null

function Initialize-Logging {
    param([string]$LogsDir)
    if (-not (Test-Path $LogsDir)) {
        New-Item -Path $LogsDir -ItemType Directory -Force | Out-Null
    }
    $stamp = Get-Date -Format "yyyy-MM-dd_HH-mm"
    $Script:LogFile = Join-Path $LogsDir "$stamp.txt"
    "PC1 Optimizer — сессия начата $(Get-Date)" | Out-File -FilePath $Script:LogFile -Encoding UTF8
}

function Write-Log {
    param(
        [Parameter(Mandatory)][string]$Message,
        [ValidateSet("INFO","WARN","ERROR","OK")][string]$Level = "INFO"
    )
    if (-not $Script:LogFile) { return }
    $line = "[{0}] [{1}] {2}" -f (Get-Date -Format "HH:mm:ss"), $Level, $Message
    Add-Content -Path $Script:LogFile -Value $line -Encoding UTF8
}

# ---------------------------------------------------------------------
#  Безопасное выполнение действия — не роняет программу при ошибке
# ---------------------------------------------------------------------
function Invoke-SafeAction {
    param(
        [Parameter(Mandatory)][string]$Description,
        [Parameter(Mandatory)][scriptblock]$Action
    )
    try {
        & $Action
        Write-Log -Message $Description -Level "OK"
        return @{ Text = $Description; Success = $true }
    }
    catch {
        Write-Log -Message "$Description :: $($_.Exception.Message)" -Level "ERROR"
        return @{ Text = $Description; Success = $false; Error = $_.Exception.Message }
    }
}

function Show-ResultList {
    param([Parameter(Mandatory)][array]$Results, [string]$Title = "Результат выполнения")
    Write-Host ""
    Write-Host " $Title" -ForegroundColor $Script:Theme.Title
    Write-Host ""
    foreach ($r in $Results) {
        if ($r.Success) {
            Write-Host "  [OK] $($r.Text)" -ForegroundColor $Script:Theme.Success
        } else {
            Write-Host "  [X]  $($r.Text) — $($r.Error)" -ForegroundColor $Script:Theme.Error
        }
    }
    Write-Host ""
    $failCount = ($Results | Where-Object { -not $_.Success }).Count
    if ($failCount -eq 0) {
        Write-Host " Операция успешно завершена." -ForegroundColor $Script:Theme.Success
    } else {
        Write-Host " Операция завершена с ошибками ($failCount). Подробности в логе." -ForegroundColor $Script:Theme.Warning
    }
    Write-Host ""
    Write-Host " Нажмите любую клавишу для возврата..." -ForegroundColor $Script:Theme.Muted
    [void][System.Console]::ReadKey($true)
}

function Show-MissingFile {
    param([string]$FileName)
    Write-Host ""
    Write-Host " [X] Файл $FileName не найден." -ForegroundColor $Script:Theme.Error
    Write-Log -Message "Файл не найден: $FileName" -Level "ERROR"
    Write-Host " Нажмите любую клавишу для возврата..." -ForegroundColor $Script:Theme.Muted
    [void][System.Console]::ReadKey($true)
}

# ---------------------------------------------------------------------
#  Диалог подтверждения Y/N
# ---------------------------------------------------------------------
function Show-Confirm {
    param([string]$Message = "Продолжить?")
    Write-Host ""
    Write-Host " $Message  [Y] Да   [N] Нет" -ForegroundColor $Script:Theme.Warning
    while ($true) {
        $k = [System.Console]::ReadKey($true)
        switch ($k.Key) {
            "Y"      { return $true }
            "Enter"  { return $true }
            "N"      { return $false }
            "Escape" { return $false }
        }
    }
}

# ---------------------------------------------------------------------
#  Меню с навигацией стрелками (и цифрами как запасной вариант)
#  $Items: массив строк-подписей. Возвращает индекс выбранного пункта
#  или -1, если пользователь нажал Esc/Q ("назад"/"выход").
# ---------------------------------------------------------------------
function Show-Menu {
    param(
        [Parameter(Mandatory)][string]$Title,
        [Parameter(Mandatory)][string[]]$Items,
        [string]$BackLabel = "[0] Назад"
    )

    $selected = 0
    $count = $Items.Count

    while ($true) {
        Write-Header -Title $Title
        for ($i = 0; $i -lt $count; $i++) {
            $label = " [{0}] {1}" -f ($i + 1), $Items[$i]
            if ($i -eq $selected) {
                Write-Host $label -ForegroundColor $Script:Theme.Highlight -BackgroundColor $Script:Theme.HighlightBg
            } else {
                Write-Host $label -ForegroundColor $Script:Theme.Text
            }
        }
        Write-Host ""
        Write-Host " $BackLabel" -ForegroundColor $Script:Theme.Muted
        Write-Host ""
        Write-Divider
        Write-Host " Стрелки: перемещение | Enter: выбор | Esc: назад | Q: выход" -ForegroundColor $Script:Theme.Muted

        $key = [System.Console]::ReadKey($true)
        switch ($key.Key) {
            "UpArrow"   { $selected = ($selected - 1 + $count) % $count }
            "DownArrow" { $selected = ($selected + 1) % $count }
            "Enter"     { return $selected }
            "Spacebar"  { return $selected }
            "Escape"    { return -1 }
            "D0"        { return -1 }
            "NumPad0"   { return -1 }
            "Q"         { Exit-Program }
            default {
                $ch = $key.KeyChar
                if ($ch -match '^[1-9]$') {
                    $idx = [int]"$ch" - 1
                    if ($idx -lt $count) { return $idx }
                }
            }
        }
    }
}

function Exit-Program {
    Write-Log -Message "Пользователь завершил работу программы." -Level "INFO"
    Clear-Host
    Write-Host "До встречи!" -ForegroundColor $Script:Theme.Accent
    exit
}

# ---------------------------------------------------------------------
#  Чек-лист выбора (для удаления мусора). Каждый элемент — hashtable:
#  @{ Name=""; Description=""; Size=""; Warning=""; Checked=$bool; Locked=$bool }
#  Locked = элемент нельзя снять/поставить (защищённый / всегда выполняется)
#  Возвращает список отмеченных элементов либо $null, если Esc.
# ---------------------------------------------------------------------
function Show-Checklist {
    param(
        [Parameter(Mandatory)][string]$Title,
        [Parameter(Mandatory)][array]$Items
    )

    $cursor = 0
    $count = $Items.Count

    while ($true) {
        Write-Header -Title $Title
        for ($i = 0; $i -lt $count; $i++) {
            $it = $Items[$i]
            $box = if ($it.Checked) { "[x]" } else { "[ ]" }
            if ($it.Locked) { $box = "[x]" }
            $line = " $box $($it.Name)"
            if ($it.Size) { $line += "  (~$($it.Size))" }

            if ($i -eq $cursor) {
                Write-Host $line -ForegroundColor $Script:Theme.Highlight -BackgroundColor $Script:Theme.HighlightBg
            } elseif ($it.Locked) {
                Write-Host $line -ForegroundColor $Script:Theme.Muted
            } else {
                Write-Host $line -ForegroundColor $Script:Theme.Text
            }
        }

        $cur = $Items[$cursor]
        Write-Host ""
        if ($cur.Description) { Write-Host "  Описание: $($cur.Description)" -ForegroundColor $Script:Theme.Muted }
        if ($cur.Warning)     { Write-Host "  Внимание: $($cur.Warning)" -ForegroundColor $Script:Theme.Warning }

        Write-Host ""
        Write-Divider
        Write-Host " Space: отметить | Enter: продолжить | Esc: назад | A: всё | N: снять всё | I: инвертировать" -ForegroundColor $Script:Theme.Muted

        $key = [System.Console]::ReadKey($true)
        switch ($key.Key) {
            "UpArrow"   { $cursor = ($cursor - 1 + $count) % $count }
            "DownArrow" { $cursor = ($cursor + 1) % $count }
            "Spacebar"  {
                if (-not $Items[$cursor].Locked) {
                    $Items[$cursor].Checked = -not $Items[$cursor].Checked
                }
            }
            "A" { for ($i=0; $i -lt $count; $i++) { $Items[$i].Checked = $true } }
            "N" { for ($i=0; $i -lt $count; $i++) { if (-not $Items[$i].Locked) { $Items[$i].Checked = $false } } }
            "I" { for ($i=0; $i -lt $count; $i++) { if (-not $Items[$i].Locked) { $Items[$i].Checked = -not $Items[$i].Checked } } }
            "Enter"  { return $Items }
            "Escape" { return $null }
        }
    }
}
