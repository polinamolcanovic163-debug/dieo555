﻿# =====================================================================
#  Modules\Network.ps1
#  Сетевые настройки: энергосбережение сетевого адаптера и USB.
# =====================================================================

function Invoke-NetworkMenu {
    while ($true) {
        $items = @(
            "Отключить энергосбережение сетевого адаптера",
            "Отключить энергосбережение USB портов",
            "Отключить Nagle Algorithm (снижение задержки TCP)"
        )
        $sel = Show-Menu -Title "Сетевые настройки" -Items $items
        switch ($sel) {
            -1 { return }
            0 { Invoke-NetworkAdapterPower }
            1 { Invoke-UsbPower }
            2 { Invoke-NagleAlgorithm }
        }
    }
}

function Invoke-NetworkAdapterPower {
    Write-Header -Title "Энергосбережение сетевого адаптера"
    if (-not (Show-Confirm -Message "Отключить энергосбережение для сетевых адаптеров?")) { return }

    $results = @()
    $results += Invoke-SafeAction -Description "Отключение энергосбережения в свойствах адаптеров" -Action {
        $keys = Get-ChildItem "HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}" -ErrorAction SilentlyContinue
        foreach ($key in $keys) {
            $p = $key.PSPath
            foreach ($prop in @("AdvancedEEE","*EEE","EEELinkAdvertisement","SipsEnabled","ULPMode","GigaLite","EnableGreenEthernet","PowerSavingMode")) {
                Set-ItemProperty -Path $p -Name $prop -Value "0" -Type String -Force -ErrorAction SilentlyContinue
            }
        }
    }
    $results += Invoke-SafeAction -Description "Отключение 'разрешить отключать это устройство для экономии энергии'" -Action {
        Get-NetAdapter -Physical -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                $pnp = Get-PnpDevice -InstanceId $_.PnPDeviceID -ErrorAction Stop
                $regPath = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($pnp.InstanceId)\Device Parameters"
                if (Test-Path $regPath) {
                    Set-ItemProperty -Path $regPath -Name "EnhancedPowerManagementEnabled" -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
                }
            } catch {}
        }
    }
    Show-ResultList -Results $results
}

function Invoke-UsbPower {
    Write-Header -Title "Энергосбережение USB портов"
    if (-not (Show-Confirm -Message "Отключить энергосбережение для USB портов и хабов?")) { return }

    $r = Invoke-SafeAction -Description "Отключение selective suspend и enhanced power management для USB" -Action {
        $usbKeys = Get-ChildItem -Path "HKLM:\SYSTEM\CurrentControlSet\Enum\USB" -Recurse -ErrorAction SilentlyContinue |
            Where-Object { $_.PSChildName -eq "Device Parameters" }
        foreach ($key in $usbKeys) {
            $p = $key.PSPath
            Set-ItemProperty -Path $p -Name "EnhancedPowerManagementEnabled" -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
        }
        # Отключаем "Разрешить отключение устройства для экономии энергии" для USB-хабов
        Get-PnpDevice -Class USB -ErrorAction SilentlyContinue | ForEach-Object {
            $devPath = "HKLM:\SYSTEM\CurrentControlSet\Enum\$($_.InstanceId)\Device Parameters"
            if (Test-Path $devPath) {
                Set-ItemProperty -Path $devPath -Name "SelectiveSuspendEnabled" -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
                Set-ItemProperty -Path $devPath -Name "SelectiveSuspendOn" -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
            }
        }
    }
    Show-ResultList -Results @($r)
}

function Invoke-NagleAlgorithm {
    Write-Header -Title "Nagle Algorithm"
    Write-Host " Отключение алгоритма Nagle может снизить задержку в онлайн-играх," -ForegroundColor $Script:Theme.Text
    Write-Host " но немного увеличить сетевой трафик мелкими пакетами." -ForegroundColor $Script:Theme.Text
    if (-not (Show-Confirm -Message "Отключить Nagle Algorithm?")) { return }

    $r = Invoke-SafeAction -Description "Отключение Nagle Algorithm для сетевых интерфейсов" -Action {
        $base = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces"
        Get-ChildItem $base -ErrorAction Stop | ForEach-Object {
            Set-ItemProperty -Path $_.PSPath -Name "TcpAckFrequency" -Value 1 -Type DWord -Force -ErrorAction SilentlyContinue
            Set-ItemProperty -Path $_.PSPath -Name "TCPNoDelay" -Value 1 -Type DWord -Force -ErrorAction SilentlyContinue
        }
    }
    Show-ResultList -Results @($r)
}
