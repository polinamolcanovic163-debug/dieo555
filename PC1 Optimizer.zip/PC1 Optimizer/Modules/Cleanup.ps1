﻿# =====================================================================
#  Modules\Cleanup.ps1
#  Удаление мусора — переработано на выбор пользователя (checklist),
#  ничего не удаляется без явного согласия. Защищённые компоненты
#  Windows никогда не показываются и не удаляются.
# =====================================================================

# Компоненты, которые НИКОГДА не показываются в списке на удаление —
# их отсутствие ломает штатную работу Windows.
$Script:ProtectedAppPatterns = @(
    "*Microsoft.WindowsStore*",
    "*Microsoft.SecHealthUI*",
    "*Microsoft.Paint*",
    "*Microsoft.WindowsNotepad*",
    "*Microsoft.WindowsCalculator*",
    "*Microsoft.Windows.Photos*",
    "*Microsoft.WindowsTerminal*",
    "*Microsoft.Windows.ShellExperienceHost*",
    "*Microsoft.Windows.StartMenuExperienceHost*",
    "*windows.immersivecontrolpanel*",
    "*Microsoft.AV1VideoExtension*",
    "*Microsoft.AVCEncoderVideoExtension*",
    "*Microsoft.HEIFImageExtension*",
    "*Microsoft.HEVCVideoExtension*",
    "*Microsoft.MPEG2VideoExtension*",
    "*Microsoft.RawImageExtension*",
    "*Microsoft.VP9VideoExtensions*",
    "*Microsoft.WebMediaExtensions*",
    "*Microsoft.WebpImageExtension*",
    "*NVIDIACorp*"
)

function Invoke-CleanupMenu {
    $sysItems = @(
        @{ Name = "Временные файлы Windows"; Description = "Файлы из %TEMP% и C:\Windows\Temp"; Checked = $true; Locked = $false; Key = "Temp" },
        @{ Name = "Prefetch";                 Description = "Кэш предзагрузки приложений";       Checked = $true; Locked = $false; Key = "Prefetch" },
        @{ Name = "Корзина";                  Description = "Полная очистка корзины";             Checked = $true; Locked = $false; Key = "RecycleBin" },
        @{ Name = "Кэш Windows Update";        Description = "Папка SoftwareDistribution\Download"; Checked = $true; Locked = $false; Key = "WuCache" },
        @{ Name = "Кэш браузеров (Chromium)";  Description = "Chrome / Edge / Brave кэш"; Checked = $false; Locked = $false; Key = "BrowserCache" }
    )

    $appCandidates = @(
        @{ Name = "Xbox Game Bar"; Pattern = "*Microsoft.XboxGamingOverlay*"; Description = "Игровая панель Windows (Win+G)."; Size = "180 МБ"; Warning = "Отключит наложение Win+G и запись видео через встроенный оверлей." },
        @{ Name = "Clipchamp";     Pattern = "*Clipchamp*";                   Description = "Встроенный видеоредактор."; Size = "250 МБ"; Warning = "" },
        @{ Name = "Microsoft Teams (персональный)"; Pattern = "*MicrosoftTeams*"; Description = "Встроенный клиент Teams."; Size = "300 МБ"; Warning = "" },
        @{ Name = "OneDrive"; Pattern = "OneDrive"; Description = "Облачная синхронизация Microsoft."; Size = "250 МБ"; Warning = "После удаления синхронизация файлов работать не будет."; IsExe = $true },
        @{ Name = "Cortana"; Pattern = "*Microsoft.549981C3F5F10*"; Description = "Голосовой ассистент Windows."; Size = "100 МБ"; Warning = "" },
        @{ Name = "Ваш телефон / Phone Link"; Pattern = "*Microsoft.YourPhone*"; Description = "Связь со смартфоном."; Size = "150 МБ"; Warning = "" },
        @{ Name = "Get Help / Тур по Windows"; Pattern = "*Microsoft.GetHelp*", "*Microsoft.Getstarted*"; Description = "Справка и приветственные советы."; Size = "50 МБ"; Warning = "" },
        @{ Name = "Skype"; Pattern = "*Microsoft.SkypeApp*"; Description = "Встроенный клиент Skype."; Size = "200 МБ"; Warning = "" },
        @{ Name = "Solitaire Collection"; Pattern = "*Microsoft.MicrosoftSolitaireCollection*"; Description = "Игровой набор пасьянсов."; Size = "150 МБ"; Warning = "" }
    )

    while ($true) {
        $items = @("Быстрая очистка временных файлов (безопасно)", "Выборочное удаление (мусор + приложения)")
        $sel = Show-Menu -Title "Удаление мусора" -Items $items
        switch ($sel) {
            -1 { return }
            0 { Invoke-QuickCleanup -Items $sysItems }
            1 { Invoke-SelectiveCleanup -SysItems $sysItems -AppItems $appCandidates }
        }
    }
}

function Invoke-QuickCleanup {
    param([array]$Items)
    $safe = $Items | Where-Object { $_.Key -ne "BrowserCache" }
    Write-Header -Title "Быстрая очистка"
    foreach ($i in $safe) { Write-Host " - $($i.Name)" -ForegroundColor $Script:Theme.Text }
    if (-not (Show-Confirm -Message "Выполнить очистку временных файлов, Prefetch, корзины и кэша обновлений?")) { return }
    $results = Invoke-CleanupActions -Keys @("Temp","Prefetch","RecycleBin","WuCache")
    Show-ResultList -Results $results
}

function Invoke-SelectiveCleanup {
    param([array]$SysItems, [array]$AppItems)

    # объединяем в один чек-лист: системные пункты + приложения (по умолчанию не выбраны)
    $checklist = @()
    foreach ($i in $SysItems) {
        $checklist += @{ Name = $i.Name; Description = $i.Description; Checked = $i.Checked; Locked = $false; Type = "sys"; Key = $i.Key }
    }
    foreach ($a in $AppItems) {
        $checklist += @{ Name = $a.Name; Description = $a.Description; Warning = $a.Warning; Size = $a.Size; Checked = $false; Locked = $false; Type = "app"; Pattern = $a.Pattern; IsExe = $a.IsExe }
    }

    $result = Show-Checklist -Title "Выберите, что удалить" -Items $checklist
    if (-not $result) { return }

    $chosen = $result | Where-Object { $_.Checked }
    if ($chosen.Count -eq 0) { return }

    Write-Header -Title "Подтверждение"
    Write-Host " Будут удалены:" -ForegroundColor $Script:Theme.Warning
    Write-Host ""
    foreach ($c in $chosen) { Write-Host "  * $($c.Name)" -ForegroundColor $Script:Theme.Text }
    Write-Host ""
    if (-not (Show-Confirm -Message "Продолжить удаление?")) { return }

    $results = @()
    $sysKeys = $chosen | Where-Object { $_.Type -eq "sys" } | ForEach-Object { $_.Key }
    if ($sysKeys) { $results += Invoke-CleanupActions -Keys $sysKeys }

    foreach ($app in ($chosen | Where-Object { $_.Type -eq "app" })) {
        $results += Invoke-SafeAction -Description "Удаление: $($app.Name)" -Action {
            if ($app.IsExe -and $app.Pattern -eq "OneDrive") {
                Stop-Process -Name "OneDrive" -Force -ErrorAction SilentlyContinue
                $unins = "$env:SYSTEMROOT\SysWOW64\OneDriveSetup.exe"
                if (-not (Test-Path $unins)) { $unins = "$env:SYSTEMROOT\System32\OneDriveSetup.exe" }
                if (Test-Path $unins) { Start-Process $unins -ArgumentList "/uninstall" -Wait -ErrorAction SilentlyContinue }
            } else {
                foreach ($pat in $app.Pattern) {
                    # никогда не трогаем защищённые компоненты, даже если пользователь как-то это выбрал
                    if ($Script:ProtectedAppPatterns -contains $pat) { continue }
                    Get-AppXPackage -AllUsers -Name $pat -ErrorAction SilentlyContinue | Remove-AppxPackage -ErrorAction SilentlyContinue
                }
            }
        }
    }
    Show-ResultList -Results $results
}

function Invoke-CleanupActions {
    param([string[]]$Keys)
    $results = @()
    foreach ($key in $Keys) {
        switch ($key) {
            "Temp" {
                $results += Invoke-SafeAction -Description "Очистка временных файлов Windows" -Action {
                    Remove-Item "$env:TEMP\*" -Recurse -Force -ErrorAction SilentlyContinue
                    Remove-Item "$env:SystemRoot\Temp\*" -Recurse -Force -ErrorAction SilentlyContinue
                }
            }
            "Prefetch" {
                $results += Invoke-SafeAction -Description "Очистка Prefetch" -Action {
                    Remove-Item "$env:SystemRoot\Prefetch\*" -Recurse -Force -ErrorAction SilentlyContinue
                }
            }
            "RecycleBin" {
                $results += Invoke-SafeAction -Description "Очистка корзины" -Action {
                    Clear-RecycleBin -Force -ErrorAction SilentlyContinue
                }
            }
            "WuCache" {
                $results += Invoke-SafeAction -Description "Очистка кэша Windows Update" -Action {
                    Stop-Service -Name wuauserv -Force -ErrorAction SilentlyContinue
                    Remove-Item "$env:SystemRoot\SoftwareDistribution\Download\*" -Recurse -Force -ErrorAction SilentlyContinue
                    Start-Service -Name wuauserv -ErrorAction SilentlyContinue
                }
            }
            "BrowserCache" {
                $results += Invoke-SafeAction -Description "Очистка кэша браузеров" -Action {
                    $paths = @(
                        "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Cache",
                        "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\Cache",
                        "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default\Cache"
                    )
                    foreach ($p in $paths) {
                        if (Test-Path $p) { Remove-Item "$p\*" -Recurse -Force -ErrorAction SilentlyContinue }
                    }
                }
            }
        }
    }
    return $results
}
