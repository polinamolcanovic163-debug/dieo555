﻿# =====================================================================
#  Modules\Gaming.ps1
#  Игровые настройки: план электропитания, GPU scheduling, Game Bar.
# =====================================================================

function Invoke-GamingMenu {
    while ($true) {
        $items = @(
            "План электропитания: Максимальная производительность",
            "Аппаратное планирование GPU (HAGS)",
            "Игровая панель (Xbox Game Bar) и Game Mode",
            "Отключить полноэкранные оптимизации (для новых окон)",
            "Приоритет игр в планировщике (System Responsiveness)"
        )
        $sel = Show-Menu -Title "Игровые настройки" -Items $items
        switch ($sel) {
            -1 { return }
            0 { Invoke-UltimatePowerPlan }
            1 { Invoke-HagsMenu }
            2 { Invoke-GameBarMenu }
            3 { Invoke-FullscreenOptimizations }
            4 { Invoke-SystemResponsiveness }
        }
    }
}

function Invoke-UltimatePowerPlan {
    Write-Header -Title "План электропитания"
    if (-not (Show-Confirm -Message "Включить план 'Максимальная производительность'?")) { return }

    $r = Invoke-SafeAction -Description "Активация плана 'Максимальная производительность'" -Action {
        $guid = "e9a42b02-d5df-448d-aa00-03f14749eb61"
        $existing = powercfg /list | Select-String $guid
        if (-not $existing) {
            powercfg -duplicatescheme $guid | Out-Null
        }
        powercfg /setactive $guid
    }
    Show-ResultList -Results @($r)
}

function Invoke-HagsMenu {
    $items = @("Включить HAGS", "Отключить HAGS")
    $sel = Show-Menu -Title "Аппаратное планирование GPU" -Items $items
    if ($sel -lt 0) { return }

    $value = if ($sel -eq 0) { 2 } else { 1 }
    $r = Invoke-SafeAction -Description "Изменение режима HAGS" -Action {
        Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" -Name "HwSchMode" -Value $value -Type DWord -Force
    }
    Show-ResultList -Results @($r)
    Write-Host " Изменения вступят в силу после перезагрузки." -ForegroundColor $Script:Theme.Warning
    Start-Sleep -Seconds 2
}

function Invoke-GameBarMenu {
    $items = @("Отключить Game Bar / Game Mode", "Включить Game Bar / Game Mode обратно")
    $sel = Show-Menu -Title "Игровая панель" -Items $items
    if ($sel -lt 0) { return }

    if ($sel -eq 0) {
        $results = @()
        $results += Invoke-SafeAction -Description "Отключение Game Bar" -Action {
            Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR" -Name "AppCaptureEnabled" -Value 0 -Type DWord -Force
        }
        $results += Invoke-SafeAction -Description "Отключение Game Mode" -Action {
            New-Item -Path "HKCU:\Software\Microsoft\GameBar" -Force -ErrorAction SilentlyContinue | Out-Null
            Set-ItemProperty -Path "HKCU:\Software\Microsoft\GameBar" -Name "AutoGameModeEnabled" -Value 0 -Type DWord -Force
        }
        Show-ResultList -Results $results
    } else {
        $results = @()
        $results += Invoke-SafeAction -Description "Включение Game Bar" -Action {
            Set-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR" -Name "AppCaptureEnabled" -Value 1 -Type DWord -Force
        }
        $results += Invoke-SafeAction -Description "Включение Game Mode" -Action {
            Set-ItemProperty -Path "HKCU:\Software\Microsoft\GameBar" -Name "AutoGameModeEnabled" -Value 1 -Type DWord -Force -ErrorAction SilentlyContinue
        }
        Show-ResultList -Results $results
    }
}

function Invoke-FullscreenOptimizations {
    Write-Header -Title "Полноэкранные оптимизации"
    Write-Host " Изменяет системную настройку по умолчанию для новых ярлыков." -ForegroundColor $Script:Theme.Text
    if (-not (Show-Confirm -Message "Отключить полноэкранные оптимизации по умолчанию?")) { return }

    $r = Invoke-SafeAction -Description "Отключение полноэкранных оптимизаций (системное значение по умолчанию)" -Action {
        Set-ItemProperty -Path "HKCU:\System\GameConfigStore" -Name "GameDVR_FSEBehaviorMode" -Value 2 -Type DWord -Force -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKCU:\System\GameConfigStore" -Name "GameDVR_HonorUserFSEBehaviorMode" -Value 1 -Type DWord -Force -ErrorAction SilentlyContinue
    }
    Show-ResultList -Results @($r)
}

function Invoke-SystemResponsiveness {
    Write-Header -Title "Приоритет игр в планировщике"
    if (-not (Show-Confirm -Message "Отдать приоритет играм (System Responsiveness = 0)?")) { return }

    $r = Invoke-SafeAction -Description "Настройка System Responsiveness и приоритета задач Games" -Action {
        $path = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile"
        Set-ItemProperty -Path $path -Name "SystemResponsiveness" -Value 0 -Type DWord -Force
        $gamesPath = "$path\Tasks\Games"
        if (-not (Test-Path $gamesPath)) { New-Item -Path $gamesPath -Force | Out-Null }
        Set-ItemProperty -Path $gamesPath -Name "Priority" -Value 6 -Type DWord -Force
        Set-ItemProperty -Path $gamesPath -Name "Scheduling Category" -Value "High" -Type String -Force
        Set-ItemProperty -Path $gamesPath -Name "GPU Priority" -Value 8 -Type DWord -Force
    }
    Show-ResultList -Results @($r)
}
