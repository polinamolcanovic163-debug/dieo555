﻿# =====================================================================
#  Assets\Colors.ps1
#  Единая цветовая тема и базовые элементы отрисовки интерфейса.
# =====================================================================

$Script:Theme = @{
    Border      = "DarkCyan"
    Title       = "Cyan"
    Text        = "Gray"
    Muted       = "DarkGray"
    Highlight   = "Black"      # цвет текста на выделенном пункте
    HighlightBg = "Cyan"       # фон выделенного пункта
    Success     = "Green"
    Warning     = "Yellow"
    Error       = "Red"
    Accent      = "Magenta"
}

function Write-Divider {
    param([int]$Width = 60)
    Write-Host ("=" * $Width) -ForegroundColor $Script:Theme.Border
}

function Write-Logo {
    $logoPath = Join-Path $PSScriptRoot "Logo.txt"
    if (Test-Path $logoPath) {
        Get-Content $logoPath | ForEach-Object {
            Write-Host $_ -ForegroundColor $Script:Theme.Accent
        }
    } else {
        Write-Host "PC1 Optimizer" -ForegroundColor $Script:Theme.Accent
    }
}

function Write-Header {
    param([string]$Title)
    Clear-Host
    Write-Divider
    Write-Logo
    Write-Divider
    if ($Title) {
        Write-Host ""
        Write-Host "   $Title" -ForegroundColor $Script:Theme.Title
        Write-Host ""
    }
}
