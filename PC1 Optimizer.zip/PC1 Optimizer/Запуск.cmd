@echo off
title PC1 Optimizer
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0PC1.ps1"
if %errorlevel% neq 0 (
    echo.
    echo Script exited with error code %errorlevel%
)
pause >nul
