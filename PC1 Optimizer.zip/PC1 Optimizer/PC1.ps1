﻿#requires -Version 5.1
<#
    PC1 Optimizer — главное меню
    Единая консольная утилита для твиков Windows.
#>

$Root = $PSScriptRoot
$ScriptPath = $PSCommandPath

try {

# ---------------------------------------------------------------------
#  Подключаем модули (порядок важен: Utilities использует $Theme)
# ---------------------------------------------------------------------
. (Join-Path $Root "Assets\Colors.ps1")
. (Join-Path $Root "Modules\Utilities.ps1")

Assert-Admin -ScriptPath $ScriptPath
$Host.UI.RawUI.WindowTitle = "PC1 Optimizer (Administrator)"
Initialize-Logging -LogsDir (Join-Path $Root "Logs")
Write-Log -Message "Программа запущена." -Level "INFO"

# ---------------------------------------------------------------------
#  Загрузка функциональных модулей с обработкой ошибок отсутствия файла
# ---------------------------------------------------------------------
$modulesOk = $true
foreach ($m in @("Cleanup.ps1","System.ps1","Nvidia.ps1","Gaming.ps1","Network.ps1","Restore.ps1")) {
    $modPath = Join-Path $Root "Modules\$m"
    if (Test-Path $modPath) {
        . $modPath
    } else {
        Show-MissingFile -FileName $m
        $modulesOk = $false
    }
}

# ---------------------------------------------------------------------
#  Дополнительные функции
# ---------------------------------------------------------------------
function Invoke-ExtrasMenu {
    while ($true) {
        $items = @(
            "Открыть папку логов",
            "О программе"
        )
        $sel = Show-Menu -Title "Дополнительные функции" -Items $items
        switch ($sel) {
            -1 { return }
            0 {
                Invoke-Item (Join-Path $Root "Logs")
            }
            1 {
                Write-Header -Title "О программе"
                Write-Host " PC1 Optimizer" -ForegroundColor $Script:Theme.Text
                Write-Host " Модульная утилита для настройки и очистки Windows." -ForegroundColor $Script:Theme.Text
                Write-Host " Логи операций сохраняются в папке Logs." -ForegroundColor $Script:Theme.Text
                Write-Host ""
                Write-Host " Нажмите любую клавишу для возврата..." -ForegroundColor $Script:Theme.Muted
                [void][System.Console]::ReadKey($true)
            }
        }
    }
}

# ---------------------------------------------------------------------
#  Главное меню
# ---------------------------------------------------------------------
function Invoke-MainMenu {
    while ($true) {
        $items = @(
            "Очистка системы",
            "Оптимизация Windows",
            "NVIDIA Tweaks",
            "Игровые настройки",
            "Сетевые настройки",
            "Дополнительные функции",
            "Восстановить всё по умолчанию 🔄"
        )
        $sel = Show-Menu -Title "Главное меню" -Items $items -BackLabel "[0] Выход"
        switch ($sel) {
            -1 { Exit-Program }
            0 { if (Get-Command Invoke-CleanupMenu -ErrorAction SilentlyContinue) { Invoke-CleanupMenu } else { Show-MissingFile -FileName "Cleanup.ps1" } }
            1 { if (Get-Command Invoke-SystemMenu  -ErrorAction SilentlyContinue) { Invoke-SystemMenu }  else { Show-MissingFile -FileName "System.ps1" } }
            2 { if (Get-Command Invoke-NvidiaMenu  -ErrorAction SilentlyContinue) { Invoke-NvidiaMenu }  else { Show-MissingFile -FileName "Nvidia.ps1" } }
            3 { if (Get-Command Invoke-GamingMenu  -ErrorAction SilentlyContinue) { Invoke-GamingMenu }  else { Show-MissingFile -FileName "Gaming.ps1" } }
            4 { if (Get-Command Invoke-NetworkMenu -ErrorAction SilentlyContinue) { Invoke-NetworkMenu } else { Show-MissingFile -FileName "Network.ps1" } }
            5 { Invoke-ExtrasMenu }
            6 { if (Get-Command Invoke-RestoreAll   -ErrorAction SilentlyContinue) { Invoke-RestoreAll }  else { Show-MissingFile -FileName "Restore.ps1" } }
        }
    }
}

Invoke-MainMenu

}
catch {
    Write-Host ""
    Write-Host "=========================================" -ForegroundColor Red
    Write-Host " Произошла критическая ошибка:" -ForegroundColor Red
    Write-Host " $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    Write-Host " $($_.InvocationInfo.PositionMessage)" -ForegroundColor DarkRed
    Write-Host "=========================================" -ForegroundColor Red
    try { Write-Log -Message "КРИТИЧЕСКАЯ ОШИБКА: $($_.Exception.Message)" -Level "ERROR" } catch {}
    Write-Host ""
    Write-Host "Нажмите любую клавишу, чтобы закрыть окно..."
    [void][System.Console]::ReadKey($true)
}
